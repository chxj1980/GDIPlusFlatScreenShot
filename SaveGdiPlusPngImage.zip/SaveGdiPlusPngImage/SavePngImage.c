#define WIN32_LEAN_AND_MEAN  /* speed up compilations */
#include <windows.h>
#include "fGdiPlusFlat.h"
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

// The function calls GetImageEncoders to get an array of 
// IMAGECODECINFO objects. If one of the IMAGECODECINFO
// objects in that array represents the requested encoder, 
// the function returns the index of the IMAGECODECINFO 
// object and copies the CLSID into the variable pointed 
// to by pClsid. If the function fails, it returns �1. 

int GetEncoderClsid(const WCHAR * format, CLSID * pClsid)
{
	UINT num = 0;	// number of image encoders
	UINT size = 0;	// size of the image encoder array in bytes

	ImageCodecInfo *pImageCodecInfo = NULL;

	GdipGetImageEncodersSize(&num, &size);
	if (size == 0)
		return -1;	// Failure

	pImageCodecInfo = GdipAlloc(size);
	if (pImageCodecInfo == NULL)
		return -1;	// Failure

	GdipGetImageEncoders(num, size, pImageCodecInfo);

	for (UINT j = 0; j < num; ++j)
	{
		if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0)
		{
			*pClsid = pImageCodecInfo[j].Clsid;
			GdipFree(pImageCodecInfo);
			return j;	// Success
		}
	}

	GdipFree(pImageCodecInfo);
	return -1;	// Failure
}

int __cdecl main(void)
{
	GpStatus status = GenericError;
	ULONG_PTR gdiplusToken;
	GdiplusStartupInput gdiplusStartupInput = {1, NULL, FALSE, FALSE};
	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

	CLSID encoderClsid;
	GpImage * image;
	status = GdipLoadImageFromFile(L"Ball.bmp", &image);
	if (status != Ok)
	{
		printf("Could not load Bird.bmp\n");
		return 0;
	}

	// Get the CLSID of the PNG encoder.
	GetEncoderClsid(L"image/png", &encoderClsid);
	status = GdipSaveImageToFile(image, L"Ball.png", &encoderClsid, NULL);

	if (status == 0)
		printf("Ball.png was saved successfully\n");
	else
		printf("Failure: status = %d\n", status);

	GdipDisposeImage(image);
	GdiplusShutdown(gdiplusToken);
	return 0;
}
