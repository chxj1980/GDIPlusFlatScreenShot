#define WIN32_LEAN_AND_MEAN  /* speed up compilations */
#include <windows.h>
#include "fGdiPlusFlat.h"
#include <stdio.h>
#include <stdlib.h>
#include <wchar.h>

// The function calls GetImageEncoders to get an array of 
// IMAGECODECINFO objects. If one of the IMAGECODECINFO
// objects in that array represents the requested encoder, 
// the function returns the index of the IMAGECODECINFO 
// object and copies the CLSID into the variable pointed 
// to by pClsid. If the function fails, it returns �1. 

int GetEncoderClsid(const WCHAR * format, CLSID * pClsid)
{
	UINT num = 0;	// number of image encoders
	UINT size = 0;	// size of the image encoder array in bytes

	ImageCodecInfo *pImageCodecInfo = NULL;

	GdipGetImageEncodersSize(&num, &size);
	if (size == 0)
		return -1;	// Failure

	pImageCodecInfo = GdipAlloc(size);
	if (pImageCodecInfo == NULL)
		return -1;	// Failure

	GdipGetImageEncoders(num, size, pImageCodecInfo);

	for (UINT j = 0; j < num; ++j)
	{
		if (wcscmp(pImageCodecInfo[j].MimeType, format) == 0)
		{
			*pClsid = pImageCodecInfo[j].Clsid;
			GdipFree(pImageCodecInfo);
			return j;	// Success
		}
	}

	GdipFree(pImageCodecInfo);
	return -1;	// Failure
}

int __cdecl main(void)
{
	// Initialize GDI+.
	GpStatus status = GenericError;
	ULONG_PTR gdiplusToken;
	GdiplusStartupInput gdiplusStartupInput = {1, NULL, FALSE, FALSE};
	GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);

	CLSID encoderClsid;
	GpImage * image;
	status = GdipLoadImageFromFile(L"Ball.bmp", &image);
	if(Ok != status)
	{
		return 0;
	}


	// Get the CLSID of the PNG encoder.
	GetEncoderClsid(L"image/jpeg", &encoderClsid);

	// Before we call GpImage_SaveFile, we can initialize an
	// EncoderParameters object. The EncoderParameters object
	// has an array of EncoderParameter objects. In this
	// case, there is only one EncoderParameter object in the array.
	// The one EncoderParameter object has an array of values.
	// In this case, there is only one value (of type ULONG)
	// in the array. We will let this value vary from 0 to 100.
	EncoderParameters encoderParameters;
	ULONG quality;
	
	encoderParameters.Count = 1;
	encoderParameters.Parameter[0].Guid = EncoderQuality;
	encoderParameters.Parameter[0].Type = EncoderParameterValueTypeLong;
	encoderParameters.Parameter[0].NumberOfValues = 1;

	// Save the image as a JPEG with quality level 100.
	quality = 100;
	encoderParameters.Parameter[0].Value = &quality;

	//(&image, GDIPCONST CLSID* clsidEncoder, GDIPCONST EncoderParameters* encoderParams);
	status = GdipSaveImageToFile(image, L"Ball.jpg", &encoderClsid, &encoderParameters);

	if (status == 0)
		printf("Ball.jpg was saved successfully\n");
	else
		printf("Failure: status = %d\n", status);

	GdipDisposeImage(image);
	GdiplusShutdown(gdiplusToken);
	return 0;
}
